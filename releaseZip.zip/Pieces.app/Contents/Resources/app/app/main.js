/**
 * Brining in the Electron app object and browser window object 
 */
const { app, BrowserWindow } = require('electron')

/**
 * Importing the Express server
 */
let server = require('../server/app.js');

/**
 * Importing the Elctron Session object 
 * This is being used to set the Content Security Policy on the electron app 
 */
const { session } = require('electron')

/**
 * Creating he window Pieces will be running in
 */
function createWindow () {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true
    }
  })

  /**
   * Loading Pieces
   * TODO: @NATHAN - Point to domain before packaging 
   */
  // win.loadURL('http://localhost:8081/')
  win.loadFile("/Users/nathancourtney/Documents/GitHub/Pieces-Electron/index.html")
  // win.loadFile("/Pieces-Electron/index.html")

  /**
   * Opening Dev Tools
   * TODO: @NATHAN - Remove before packaging
   */
  win.webContents.openDevTools()
}

/**
 * Lifecycle called when the app is ready 
 */
app.whenReady().then( _ => {
  createWindow;
    try {
      // console.log('Sending Hello')
      // server.hello()
      // console.log("Sent?")
    } catch (err) {console.log('ERROR', err)}


  // CONTENT SECUREITUY POLICY FOR ELECTRON
  // session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
  //   callback({
  //     responseHeaders: {
  //       ...details.responseHeaders,
  //       'Content-Security-Policy': ['default-src \'none\'']
  //     }
  //   })
  // })
}) 

/**
 * Tearing down the application on window closed 
 */
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    server.quit()
    app.quit()
  }
})

/**
 * Building the window again when the app is re-activated
 */
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})
