
/**
 * Express 
 * https://expressjs.com/
 * 
 * This is the core of the server 
 */
const express = require('express');

/**
 * WebSocket Node Library 
 * https://github.com/websockets/ws
 * 
 * This is the protocol we use to communicate with the server 
 */
const ws = require('ws');

/**
 * Node Child Process 
 * This is used to open our embeded swift application
 * It basically just points to the file location and executes it 
 */
var cp = require("child_process");

/**
 * JSON Web token 
 * Could be used for some token auth - probably won't need likely remove
 */
var jwt = require('jsonwebtoken');
// How to sign a token
var token = jwt.sign({ foo: 'bar' }, 'secret');

/**
 * Helmet
 * https://www.npmjs.com/package/helmet
 * 
 * Node library that Works with express to set HTTP Headers and help block people attempting a XSS attack 
 */
var helmet = require('helmet')

/**
 * Another express module to manipulate the session object
 * Being used to prevent cookie stealing - probably won't need
 * 
 * Good Article about security 
 * https://medium.com/@rajapradhan08/best-practices-for-securing-node-js-web-applications-2e54cfefdc05
 * 
 */
var session = require('express-session')
var cookieParser = require('cookie-parser')

/**
 * This is the node app class that creates our express server and websocket server alongside
 * The Express server is the server that is actually running, the websocket server is loaded into the Express server.
 * The webscoket server can be thought as the manager for all the websockets, while the express server can be thought as the host 
 */
class App {

    /**
     * Creating a new Express app
     */
    app = express();

    constructor() {

        /**
         * Setting the Port number
         * @NATHAN - Probably will use a different number, also TODO: Look into setting environment variables
         */
        const port = process.env.PORT || 2233

        /**
         * Creating the websocket server, without actually spinning up a node server 
         */
        const wsServer = new ws.Server({ noServer: true });

        /**
         * Fires when a websocket connnects with the server
         */
        wsServer.on('connection', socket => {

            console.log("Socket Protocal?",socket.protocol);

            /**
             * Fires when the websocket server receives a message
             */
            socket.on('message', message => {

                // console.log('web socket received: %s', message);

                /**
                 * Looping over each connected client to either brodacast the massage or to send to a specified client
                 */
                wsServer.clients.forEach(client => {

                    const fromMacOS = /^fromMacOS\:/;
                    const fromMacOSClipboard = /^fromMacOSClipboard\:/;

                    // Sent from JS -> Response back to JS if message satisfies 
                    if (client.protocol === "jsClient" && socket.protocol === "jsClient") {

                        const helloJS = /^hellofromjs\:/;

                        // Sending a Hello Response back to the JS client
                        if (helloJS.test(message)) {
                            message = message.replace(helloJS, '');
                            client.send(`Hello Js Client! I am the server`);
                        }
                        
                    } 

                    // Send to all other clients (macOS) and not the JS client from the JS client 
                    if (client.protocol !== "jsClient" && socket.protocol === "jsClient") {
                            client.send(`${message}`);
                    } 

                    /**
                     * THIS WILL ONLY FIRE THE INIT MESSAGE IF THE ELECTRON APP IS OPENED BEFORE THE BACKGROUND APP
                     */
                    // Sent From JS -> macOSClient
                    if (client.protocol === "jsClient" && fromMacOS.test(message)) {
                        message = message.replace(fromMacOS, '');
                        console.log(message);
                        client.send(`MACOS:: ${message}`);
                    }

                    // From macOS clipboard
                    if (client.protocol === "jsClient" && fromMacOSClipboard.test(message)) {
                        message = message.replace(fromMacOSClipboard, '');
                        console.log(message);
                        client.send(`fromMacOSClipboard:${message}`);
                    }

                });
            });
        });

         // HELMET - some real basic security 
        this.app.use(helmet())

         /** 
          * Handle 404
          * Swaping the default 404 message to help hide the fact we are using Express
          * Not fool proof security but was recommended 
          * TODO @NATHAN - Currently throwing errors, probably need to remove or figure out what is going on 
         */
        // this.app.use(function(req, res) {
        //     res.status(400);
        //     res.render('404', {title: '404: File Not Found'});
        //  });
 
        // Handle 500
        // this.app.use(function(error, req, res, next) {
        //     res.status(500);
        //     res.render('500', {title:'500: Internal Server Error', error: error});
        //  });

        this.app.use(cookieParser());

        /**
         * TODO: @NAHTAN - look into why this is throwing deprecation warnings
         * We might not even need to to this
         */
        // this.app.use(session({
        //     secret: "s3Cur3",
        //     cookie: {
        //         httpOnly: true,
        //         secure: true
        //     }
        // }));

        /**
         * This is the creation of the actual express server 
         * This is where we set the Port and begin listening for changes
         */
        const server = this.app.listen(port, () => {
            console.log(`Server app listening at http://localhost:${port}`)
        })
        
        /**
         * This function handles incoming requests to the Express server and then emits them to the websocket server
         * Since the WebSocket server isn't actually running as a standalone server, the express server sort of acts like a medium to facilitate communication
         */
        server.on('upgrade', (request, socket, head) => {
            wsServer.handleUpgrade(request, socket, head, socket => {
                wsServer.emit('connection', socket, request);
            });
        });
          
        this.app.get('/', (req, res) => {
            res.send("Hello Pieces Node Server")
        })
    }

    /**
     * This funciton targets the location of the embded swift app and launches it through use of a node child process
     */
    openBackgroundService() {
        console.log("Attempting to Open Background Service...");

        const productionPath = process.resourcesPath + '/app/extraResources/Pieces-OSX.app';

        const localTestingPath = "./extraResources/Pieces-OSX.app";

        console.log("Prod Path: ",productionPath);

        cp.exec('open '+ productionPath, function (err, stdout, stderr) {
            if (err) {
                console.log("ERROR", err)
                throw err;
            }
            else {
                console.log("Background service opened successfully");
            }
        })
        // process.exit(0); // exit this nodejs process
    }

}

/**
 * Exporting the server as an new instance of itself
 */
module.exports = new App();
