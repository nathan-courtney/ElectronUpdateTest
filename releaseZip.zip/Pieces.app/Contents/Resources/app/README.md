# Pieces-Electron
 Pieces Installable Electron Application

*****************************

HOW TO PACKAGE
|| use npm script: electron:mac:package


HOW TO DMG
|| use npm script: electron:mac:dmg
*** If it throws an error, run: sudo npm install -g appdmg --unsafe



